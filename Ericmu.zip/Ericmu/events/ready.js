const Discord = require('discord.js');
const utils = require('../utils');

module.exports = client => {
    utils.log(`Logged in as ${client.user.username}!`);
    console.log(`${client.user.tag} - rich presence started!`);

    const activity = {
        type: 'LISTENING', // You can set any other type like PLAYING, LISTENING, STREAMING
        name: 'Eric', // Your name
        details: 'Pact on top', // Your status
        // state: 'Version: 0.9', // Optional state
        url: 'https://discord.gg/YW9t2hAp4a', // Set any YouTube or Twitch link
        timestamps: { start: Date.now() }, // Current time
        assets: {
            largeImage: 'https://f.top4top.io/p_2964kho9s1.gif', // Image link (form: .png, .gif).
            largeText: 'PACT' // Image name (type any name)
        },
        buttons: [{ label: 'Pact server', url: 'https://discord.gg/YW9t2hAp4a' }] // Button name and link
    };
    
    client.user.setActivity(activity);
    client.user.setStatus("online"); // Set your status (online, dnd, idle)
};
